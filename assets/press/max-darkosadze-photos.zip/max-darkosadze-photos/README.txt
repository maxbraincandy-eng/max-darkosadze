Photographs of Max Darkosadze (Batoni Maksi) for editorial use.
მაქს დარკოსაძის ფოტოები რედაქციული გამოყენებისთვის.

Please credit the photographer where known.
გთხოვთ, მიუთითოთ ფოტოს ავტორი, სადაც ცნობილია.
